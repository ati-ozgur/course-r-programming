for (val in 1:100)
{
        if (val %% 15 == 0 )
        {
                print("fifteen")        
        }
        else if (val %% 5 == 0 )
        {
                print("five")        
                
        }
        else if (val %% 3 == 0 )
        {
                print("three")        
                
        }else
        {
                print(val)
        }
}
