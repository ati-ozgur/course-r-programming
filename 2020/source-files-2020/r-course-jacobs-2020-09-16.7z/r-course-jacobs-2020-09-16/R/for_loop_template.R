#
seq_or_list_like_object = 1:100
for(val in seq_or_list_like_object)
{
   print(val)
}
