library(readxl)
df1 <- read_excel("data/deneme1.xlsx",sheet = "Sheet2")

for (val in df1$Grade)
{
        if (val >= 90)
        {
            line = paste("grade number",val,"grade char","AA")
        }
        else if (val >= 85)
        {
                line = paste("grade number",val,"grade char","BA",sep=":")
        }
        else
        {
                line = paste("grade number",val,"grade char","NI",sep=":")
        }
        print(line)
}


