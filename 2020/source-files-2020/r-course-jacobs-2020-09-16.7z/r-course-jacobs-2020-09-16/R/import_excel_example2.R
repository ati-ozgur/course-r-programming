data2 <- read.csv("data/deneme1.csv")

