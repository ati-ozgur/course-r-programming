a1 <- sample(1:40,100 , replace=T)
a1 > 20
a1[a1> 20]
