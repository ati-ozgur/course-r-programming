student_count = 100
# may need 
#install.packages("randNames")
library("randNames") 

names = rand_names(n = student_count,nationality="DE")
first_name = names$name.first
last_name = names$name.last
grades = sample(40:100,student_count,replace=T)

df = data.frame(first_name, last_name, grades)

write.csv(df,file="data/grades.csv",row.names=FALSE)
