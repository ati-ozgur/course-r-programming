a1 <- sample(1:40,10 , replace=T)

a2 <- sample(1:40,41 , replace=F)


dice = sample(1:6,10 , replace=T)

coin_tossing = sample(c("Heads","Tails"),20,replace=T)
