numbers = 1:100
str_numbers = as.character(numbers)
str_numbers[numbers %% 5 == 0] = "five"
str_numbers[numbers %% 3 == 0] = "three"
str_numbers[numbers %% 15 == 0] = "fifteen"
str_numbers

# numbers == 5
# 
# numbers %% 3 == 0
# 
# a3 = number %% 3
# a3 == 0


