student_count = 1000
# may need 
#install.packages("randNames")
library("randNames") 

names = rand_names(n = student_count)
first_name = names$name.first
last_name = names$name.last
grades = rnorm(student_count, mean = 75, sd = 10)

grades_int = as.integer(round(grades))

df = data.frame(first_name, last_name, grades_int)

colnames(df) = c("first_name","last_name","grades")

write.csv(df,file="data/grades.csv",row.names=FALSE)
