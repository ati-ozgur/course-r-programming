library(readr)
#df_grades <- read_csv("data/grades_uniform.csv", locale = locale(encoding = "ISO-8859-1"))
df_grades <- read_csv("data/grades.csv", locale = locale(encoding = "ISO-8859-1"))

library(ggplot2)
# Basic histogram
p = ggplot(df_grades, aes(x=grades))  + 
        geom_histogram(binwidth=5)
print(p)
