library(readr)
#df_grades <- read_csv("data/grades_uniform.csv", locale = locale(encoding = "ISO-8859-1"))
df_grades <- read_csv("data/grades.csv", locale = locale(encoding = "ISO-8859-1"))

hist(df_grades$grades)
