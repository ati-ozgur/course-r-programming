a = 2
x = a**2
print(a)
print(x)
