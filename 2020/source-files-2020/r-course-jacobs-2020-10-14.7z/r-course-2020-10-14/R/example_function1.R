name_of_function <- function(){
        # body of function
}
