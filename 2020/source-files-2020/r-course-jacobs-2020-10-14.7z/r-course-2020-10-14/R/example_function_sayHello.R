sayHello <- function(name){
        ret = paste("Hallo, " , name,sep=" ")
        return(ret)
        
}
