sayHello2 <- function(name, place="Bremen"){
        ret = paste("Hello from ",place, "to" , name,sep=" ")
        return(ret)
        
}
