date1=strptime( c("20170225230000","20170226000000", "20170226010000"),format="%Y%m%d%H%M%S")


d1 = strptime("20201021084600",,format="%Y%m%d%H%M%S")
d2 = strptime("2020-10-21 08:46:00",,format="%Y-%m-%d %H:%M:%S")
