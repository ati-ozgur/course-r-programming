library(readr)
df_bitcoin <- read_csv("data/bitcoin_historical_data.csv",
col_types = cols(Date = col_date(format = "%b %d, %Y")))

names(df_bitcoin) = c("Date","Open","High","Low","Close","Volume","MarketCap")
#View(df_bitcoin)
plot(df_bitcoin$Date,df_bitcoin$Open,type="l")

# format values here.
# https://www.statmethods.net/input/dates.html

# example ggplot figures are here
# https://github.com/prouast/cryptocurrency-analysis/blob/master/analysis.R
