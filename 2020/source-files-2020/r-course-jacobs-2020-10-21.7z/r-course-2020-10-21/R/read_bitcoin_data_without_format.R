library(readr)
df_bitcoin <- read_csv("data/bitcoin_historical_data.csv")
                       
df_bitcoin$Date2 = strptime(df_bitcoin$Date,format="%b %d, %Y")
