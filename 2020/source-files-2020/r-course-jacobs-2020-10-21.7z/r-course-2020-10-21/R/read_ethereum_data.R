library(readr)
df_ethereum <- read_csv("data/ethereum_historical_data20170101-20201020.csv",
col_types = cols(Date = col_date(format = "%b %d, %Y")))

names(df_ethereum) = c("Date","Open","High","Low","Close","Volume","MarketCap")
View(df_ethereum)

# format values here.
# https://www.statmethods.net/input/dates.html

# example ggplot figures are here
# https://github.com/prouast/cryptocurrency-analysis/blob/master/analysis.R
