library(tidyverse)
library(xml2)
library(rvest)
webpage_url <- "https://coinmarketcap.com/currencies/bitcoin/historical-data/?start=20130429&end=20201021"

content <- read_html(webpage_url)
tables <- content %>% html_table(fill = TRUE)

tb_prices = tables[[3]]



write.csv(tb_prices,"data/bitcoin_historical_data.csv", row.names = FALSE)
