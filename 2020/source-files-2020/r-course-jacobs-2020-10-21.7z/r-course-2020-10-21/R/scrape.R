library(tidyverse)
library(xml2)
library(rvest)
webpage_url <- "https://coinmarketcap.com/currencies/ethereum/historical-data/?start=20170101&end=20201019"

content <- read_html(webpage_url)
tables <- content %>% html_table(fill = TRUE)

tb_prices = tables[[3]]



write.csv(tb_prices,"data/ethereum_historical_data.csv", row.names = FALSE)
