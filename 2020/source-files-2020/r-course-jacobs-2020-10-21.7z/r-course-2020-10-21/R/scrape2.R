library(tidyverse)
library(xml2)
library(rvest)

startdate="20170101"
enddate="20201020"

webpage_url <- paste("https://coinmarketcap.com/currencies/ethereum/historical-data/?start=",startdate,"&end=",enddate,sep="")

content <- read_html(webpage_url)
tables <- content %>% html_table(fill = TRUE)

tb_prices = tables[[3]]


csv_filename = paste("data/ethereum_historical_data",startdate,"-",enddate,".csv",sep="")
write.csv(tb_prices,csv_filename, row.names = FALSE)
