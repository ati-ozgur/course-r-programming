random_numbers = rnorm(100)
plot(random_numbers)
