 
plot(rnorm(100))
