
min_value = 10
max_value = 50

find_color1 <- function(test_result){
        # function body to do something
        #If the test result is less than min or higher than max, your function will return “red”.
        #If the test result is between min and max, then your function will return “green”
        if ((test_result < min_value) || (test_result > max_value))
        {
                return("red")
        }else
        {
                return("green")
        }

}


find_color1(30)
find_color1(52)
