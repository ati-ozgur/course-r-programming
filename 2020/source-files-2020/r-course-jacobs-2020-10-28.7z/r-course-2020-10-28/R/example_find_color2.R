

find_color2 <- function(min_test_value,max_test_value,current_test_value){
        # function body to do something
        #If the test result is less than min or higher than max, your function will return “red”.
        #If the test result is between min and max, then your function will return “green”
        if ((current_test_value < min_test_value) || (current_test_value > max_test_value))
        {
                return("red")
        }else
        {
                return("green")
        }

}


find_color2(10,50,30)
find_color2(10,50,52)
find_color2(20,200,30)
find_color2(20,200,220)
