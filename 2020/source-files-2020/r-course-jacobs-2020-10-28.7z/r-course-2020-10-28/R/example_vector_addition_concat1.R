a1 = 1:5
a2 = (1:5)**2


print(a1+1)

print(a1+a2)

print(a1*a2)

a_c = c(a1,a2)
