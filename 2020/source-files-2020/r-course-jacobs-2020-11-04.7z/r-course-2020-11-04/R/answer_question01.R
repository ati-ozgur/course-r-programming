find_color <- function(min_test_value,max_test_value,current_test_value){
        # function body to do something
        #If the test result is less than min or higher than max, your function will return “red”.
        #If the test result is between min and max, then your function will return “green”
        if ((current_test_value < min_test_value) || (current_test_value > max_test_value))
        {
                return("red")
        }else
        {
                return("green")
        }

}


print( paste("min_test_value 10,max_test_value,50, current_test_value,30, color:",   find_color(10,50,30)))
print( paste("min_test_value 10,max_test_value,50, current_test_value,52, color:",   find_color(10,50,52)))
print( paste("min_test_value 20,max_test_value,200, current_test_value,30, color:",   find_color(20,200,30)))
print( paste("min_test_value 20,max_test_value,200, current_test_value,220, color:",   find_color(20,200,220)))
