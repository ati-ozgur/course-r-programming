count_medical_tests = 8

count_test_results = 100

current_test_number = 1
min_test_value = current_test_number*10
max_test_value = (current_test_number**2)*50
all_test_values = as.integer( runif(count_test_results,min=min_test_value,max=max_test_value))

for (current_test_number in 2:count_medical_tests)
{
	min_test_value = current_test_number*10
	max_test_value = (current_test_number**2)*50
	current_test_value = as.integer( runif(count_test_results,min=min_test_value,max=max_test_value))
	all_test_values = c(all_test_values,current_test_value)
	print(current_test_number)
}

