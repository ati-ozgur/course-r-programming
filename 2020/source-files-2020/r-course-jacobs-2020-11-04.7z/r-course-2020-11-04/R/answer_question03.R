source("R/find_color.R")
source("R/find_color_new.R")

count_medical_tests = 8

count_test_results = 100

all_medical_tests = c()
all_colors = c()
all_colors_new = c()
all_current_test_values = c()
all_min_test_values = c()
all_max_test_values = c()
for (current_test_number in 1:count_medical_tests)
{
	current_medical_test_name = paste("Medical Test",current_test_number)
	min_test_value = current_test_number*10
	max_test_value = (current_test_number**2)*50
	for(current_test in 1:count_test_results)
	{
			current_test_value = as.integer( runif(1,min=min_test_value-10,max=max_test_value+10))
			color = find_color(min_test_value,max_test_value,current_test_value)
			color_new = find_color_new(min_test_value,max_test_value,current_test_value)
			all_colors = c(all_colors,color)
			all_colors_new = c(all_colors_new,color_new)
			all_current_test_values = c(all_current_test_values,current_test_value)
			all_min_test_values = c(all_min_test_values,min_test_value)
			all_max_test_values = c(all_max_test_values,max_test_value)
			all_medical_tests = c(all_medical_tests,current_medical_test_name)
	}
	print(current_test_number)
}


df = data.frame(all_medical_tests,all_min_test_values, all_max_test_values,all_current_test_values,all_colors,all_colors_new)
colnames(df) = c("medical_test_name","min_test_value", "max_test_value","current_test_value","color","color2")



write.csv(df, file = 'data/question03.csv')

