png(file="answer_to_question04.png")
hist(df$current_test_value)
dev.off()