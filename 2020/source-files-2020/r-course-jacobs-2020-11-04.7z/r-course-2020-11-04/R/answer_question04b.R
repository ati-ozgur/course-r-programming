png(file="answer_to_question04_plot1.png")
plot(df$current_test_value,df$min_test_value,col=df$color)
dev.off()

png(file="answer_to_question04_plot2.png")
plot(df$current_test_value,df$min_test_value,col=df$color2)
dev.off()

