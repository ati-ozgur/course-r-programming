value_count = 100

random_values1 = as.integer( runif(100,min=10,max=50))
random_values2 = as.integer( runif(100,min=10,max=50))


df = data.frame(random_values1, random_values2)

write.csv(df,file="data/example_dataframe.csv",row.names=FALSE)
