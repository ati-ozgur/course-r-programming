value_count = 100

random_values_test1 = as.integer( runif(100,min=10,max=50))
random_values_test2 = as.integer( runif(100,min=20,max=200))

random_test_values = c(random_values_test1,random_values_test2)

#df = data.frame(random_values1, random_values2)

#write.csv(df,file="data/example_dataframe.csv",row.names=FALSE)
