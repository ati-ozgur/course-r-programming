
example_function1 <- function(){
        # function body to do something
}


example_function2 <- function(arg1){
        # function body to do something
}

