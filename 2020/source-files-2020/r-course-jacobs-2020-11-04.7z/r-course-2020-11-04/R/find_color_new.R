find_color_new <- function(min_test_value,max_test_value,current_test_value){
        # function body to do something
        if (current_test_value <= min_test_value)
        {
                color = "yellow"
        } 
        else if (current_test_value >= max_test_value)
        {
                color =  "red"
        }else
        {
                color = "green"
        }
        #print( paste("min_test_value:",min_test_value," max_test_value:",max_test_value," current_test_value",current_test_value," color:",  color))
        return(color)
}


find_color_new(10,50,30)
find_color_new(10,50,52)
find_color_new(10,50,5)
find_color_new(20,200,30)
find_color_new(20,200,220)
find_color_new(20,200,10)
