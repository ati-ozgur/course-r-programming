germany <- c(
        "Germany")
# Retrievethe map data
germany.maps <- map_data("world", region = germany)
ggplot(germany.maps, aes(long, lat, group = group)) +
        geom_polygon(fill = "white", colour = "black")
