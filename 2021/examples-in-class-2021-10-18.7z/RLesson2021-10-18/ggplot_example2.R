df = faithful
#View(df)
library("tidyverse")
ggplot(data = df, mapping = aes(x=eruptions,y = waiting)) +
         geom_point()
