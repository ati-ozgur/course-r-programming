df = faithful
#View(df)
library("tidyverse")
g = ggplot(data = df, mapping = aes(x=waiting,y = eruptions))
g = g + geom_point()
print(g)
