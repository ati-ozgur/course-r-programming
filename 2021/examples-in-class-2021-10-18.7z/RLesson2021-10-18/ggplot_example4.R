df = faithful
#View(df)
library("tidyverse")
g = ggplot(data = df, mapping = aes(x=eruptions,y = waiting))
g = g + geom_line()
print(g)
