
library(shiny)
ui <- fluidPage(
        sliderInput(inputId = "num",
                    label = "Choose a number",
                    value = 25, min = 10, max = 200),
        plotOutput("hist")        
        
)
server <- function(input, output) {
        
        output$hist <- renderPlot({
                title <- paste(input$num," random normal values")
                xlab = paste(input$num," norm")

                hist(rnorm(input$num),main=title,xlab=xlab)
                #hist(rnorm(input$num))
        })        
        
        
}
shinyApp(ui = ui, server = server)
