tb <- tibble(
        `:)` = "smile", 
        ` ` = "space",
        `2000` = "number"
)
print(tb)
