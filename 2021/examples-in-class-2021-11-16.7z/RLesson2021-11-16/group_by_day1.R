library(nycflights13)
library(tidyverse)
df = nycflights13::flights

by_day = group_by(df, year, month, day)
result1 = summarise(by_day, delay = mean(dep_delay, na.rm = TRUE))
print(result1)
