library(nycflights13)
library(tidyverse)
df = nycflights13::flights
by_day2 <- group_by(flights, day, month, year)
result2 = summarise(by_day2, delay = mean(dep_delay, na.rm = TRUE))
print(result2)
