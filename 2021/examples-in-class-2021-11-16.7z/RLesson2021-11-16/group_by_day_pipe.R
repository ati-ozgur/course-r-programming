library(nycflights13)
library(tidyverse)
df = nycflights13::flights

df %>%  
group_by( year, month, day) %>%
summarise( delay = mean(dep_delay, na.rm = TRUE)) %>%
print()
