library(nycflights13)
library(tidyverse)


jan1 <- filter(flights,year == 2013,month==1,day==1)



arrange(jan1,dep_delay)


arrange(jan1,dep_delay,arr_time)


arrange(jan1,desc(dep_delay),arr_time)
