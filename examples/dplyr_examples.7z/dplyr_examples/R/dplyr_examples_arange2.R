df <- tibble(x = c(5, 2, NA))

arrange(df, desc(x))
