library(nycflights13)
library(tidyverse)

jan1 <- filter(flights,year == 2013,month==1,day==1)


(jan1 <- filter(flights,year == 2013,month==1,day==1))


filter(flights, month == 11 | month == 12)


filter(flights, (month == 11 & day == 1) | (month == 12 & day == 1))


filter(flights, month %in% c(11,12) & day == 1)
