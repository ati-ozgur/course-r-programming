library(nycflights13)
library(tidyverse)


jan1 <- filter(flights,year == 2013,month==1,day==1)

jan1 <- select(jan1,  year:day, 
               ends_with("delay"), 
               distance, 
               air_time
)

mutate(jan1,
       gain = dep_delay - arr_delay,
       speed = distance / air_time * 60
)

transmute(jan1,
       gain = dep_delay - arr_delay,
       speed = distance / air_time * 60
)
