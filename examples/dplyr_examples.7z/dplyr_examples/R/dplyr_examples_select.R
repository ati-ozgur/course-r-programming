library(nycflights13)
library(tidyverse)


jan1 <- filter(flights,year == 2013,month==1,day==1)


select(jan1,origin,dest)

select(jan1,starts_with("dep"),ends_with("time"))


temp_jan1 <- select(jan1,origin,dest,everything())
