library(nycflights13)
library(tidyverse)


jan1 <- filter(flights,year == 2013,month==1,day==1)

summarise(jan1,delay = mean(dep_delay,na.rm = TRUE))

summarise(flights, delay = mean(dep_delay, na.rm = TRUE))

by_day <- group_by(flights, year, month, day)
summarise(by_day, delay = mean(dep_delay, na.rm = TRUE))


by_month <- group_by(flights, year, month)
df2 <- summarise(by_month, delay = mean(dep_delay, na.rm = TRUE))

arrange(df2,desc(delay))



