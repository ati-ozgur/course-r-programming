library(nycflights13)
library(tidyverse)

# No pipe        
        
by_month <- group_by(flights, year, month)
df2 <- summarise(by_month, delay = mean(dep_delay, na.rm = TRUE))

arrange(df2,desc(delay))

# Pipe operator %>%
group_by(flights, year, month)  %>%
        summarise(delay = mean(dep_delay, na.rm = TRUE)) %>%
        arrange(desc(delay))
